package com.fishingingreece.app;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public final class PublicSpotService {
    public interface Callback { void done(List<FishingSpot> spots, String error); }
    private static final ExecutorService POOL=Executors.newSingleThreadExecutor();
    private PublicSpotService(){}
    public static void fetchGreece(Callback callback){POOL.execute(()->{
        try{
            String query="[out:json][timeout:50];area[\"ISO3166-1\"=\"GR\"][admin_level=2]->.gr;(nwr[\"leisure\"=\"fishing\"](area.gr);nwr[\"fishing\"=\"yes\"](area.gr);nwr[\"fishing\"=\"designated\"](area.gr););out center tags;";
            HttpURLConnection connection=(HttpURLConnection)new URL("https://overpass-api.de/api/interpreter?data="+URLEncoder.encode(query,StandardCharsets.UTF_8)).openConnection();
            connection.setConnectTimeout(15000);connection.setReadTimeout(55000);connection.setRequestProperty("User-Agent","FishingInGreece/0.2.3");
            String json;try(InputStream in=connection.getInputStream()){json=new String(in.readAllBytes(),StandardCharsets.UTF_8);}finally{connection.disconnect();}
            JSONArray elements=new JSONObject(json).optJSONArray("elements");List<FishingSpot> result=new ArrayList<>();if(elements!=null)for(int i=0;i<elements.length();i++){
                JSONObject e=elements.getJSONObject(i);double lat=e.optDouble("lat",Double.NaN),lon=e.optDouble("lon",Double.NaN);JSONObject center=e.optJSONObject("center");if(center!=null){lat=center.optDouble("lat",lat);lon=center.optDouble("lon",lon);}if(Double.isNaN(lat)||Double.isNaN(lon))continue;
                JSONObject tags=e.optJSONObject("tags");if(tags==null)tags=new JSONObject();String name=tags.optString("name:el",tags.optString("name","Δηλωμένος δημόσιος ψαρότοπος"));String region=tags.optString("addr:place",tags.optString("addr:city","Ελλάδα"));String type=tags.optString("fishing","");String fish=type.isBlank()?"Δεν έχουν δηλωθεί συγκεκριμένα είδη":"Δήλωση OSM: "+type;
                int id=(int)(1_000_000L+Math.abs(e.optLong("id",i)%900_000L));result.add(new FishingSpot(id,name,region,lat,lon,"Δεν έχει δηλωθεί","Υπολογίζεται ζωντανά από EMODnet",fish,"Δεν έχει δηλωθεί","Δημόσια καταχώριση OpenStreetMap","Επιβεβαίωσε επιτόπου πρόσβαση, ιδιοκτησία και τοπικούς περιορισμούς.",false));
            } callback.done(result,"");
        }catch(Exception error){callback.done(Collections.emptyList(),"Δεν ήταν δυνατή η φόρτωση των δημόσιων καταχωρίσεων.");}
    });}
}
