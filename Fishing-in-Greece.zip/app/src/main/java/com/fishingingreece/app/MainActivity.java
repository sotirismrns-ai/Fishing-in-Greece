package com.fishingingreece.app;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.*;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    private final List<FishingSpot> spots=SpotRepository.all();
    private final List<FishGuideEntry> fishGuide=FishGuideRepository.all();
    private AppDatabase db; private LinearLayout body; private MapView map; private String selectedPhoto=""; private TextView weatherView;
    private GestureDetector backSwipeDetector;
    private int navy=Color.rgb(6,43,70), ocean=Color.rgb(8,126,164), foam=Color.rgb(244,250,252), coral=Color.rgb(255,122,89);
    @Override protected void onCreate(Bundle b){ super.onCreate(b); org.osmdroid.config.Configuration.getInstance().setUserAgentValue(getPackageName()); db=new AppDatabase(this); setupBackSwipe(); buildShell(); showHome(); }
    private void setupBackSwipe(){
        backSwipeDetector=new GestureDetector(this,new GestureDetector.SimpleOnGestureListener(){
            @Override public boolean onDown(MotionEvent e){return true;}
            @Override public boolean onFling(MotionEvent start,MotionEvent end,float velocityX,float velocityY){
                if(start==null||end==null)return false; float edge=48*getResources().getDisplayMetrics().density; float dx=end.getX()-start.getX(); float dy=Math.abs(end.getY()-start.getY());
                if(start.getX()<=edge&&dx>120&&dx>dy&&velocityX>200){onBackPressed();return true;} return false;
            }
        });
    }
    @Override public boolean dispatchTouchEvent(MotionEvent event){if(backSwipeDetector!=null&&backSwipeDetector.onTouchEvent(event))return true;return super.dispatchTouchEvent(event);}
    private void buildShell(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(foam);
        getWindow().setStatusBarColor(navy); getWindow().setNavigationBarColor(navy);
        root.setOnApplyWindowInsetsListener((v,insets)->{v.setPadding(0,insets.getSystemWindowInsetTop(),0,insets.getSystemWindowInsetBottom());return insets;});
        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setBackgroundColor(navy); header.setPadding(14,10,14,10);
        ImageView logo=new ImageView(this); logo.setImageResource(R.drawable.ic_launcher); logo.setScaleType(ImageView.ScaleType.CENTER_CROP); header.addView(logo,new LinearLayout.LayoutParams(72,72));
        TextView brand=text("Fishing in Greece",24,Color.WHITE); brand.setGravity(Gravity.CENTER); brand.setTypeface(null,1); header.addView(brand,new LinearLayout.LayoutParams(0,72,1));
        root.addView(header,new LinearLayout.LayoutParams(-1,-2));
        body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); root.addView(body,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout nav=new LinearLayout(this); nav.setBackgroundColor(navy); String[] names={"⌂ Αρχική","⌖ Χάρτης","🎣 Εξορμήσεις"};
        for(int i=0;i<3;i++){ Button x=button(names[i]); final int n=i; x.setOnClickListener(v->{if(n==0)showHome();else if(n==1)showMap();else showTrips();}); nav.addView(x,new LinearLayout.LayoutParams(0,62,1)); }
        root.addView(nav); setContentView(root);
    }
    private void clear(){ if(map!=null){map.onPause(); map=null;} body.removeAllViews(); }
    private void showHome(){
        clear();
        LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(8,6,8,8); body.addView(page,new LinearLayout.LayoutParams(-1,-1));
        ImageView hero=homeImage(R.drawable.home_hero,"Καλώς ήρθες στο Fishing in Greece"); LinearLayout.LayoutParams heroParams=new LinearLayout.LayoutParams(-1,0,1.05f); heroParams.setMargins(4,0,4,4); page.addView(hero,heroParams);
        LinearLayout row1=homeRow(); row1.addView(homeCard(R.drawable.home_spots,"Ψαρότοποι",v->showMap())); row1.addView(homeCard(R.drawable.home_weather,"Καιρός και Θάλασσα",v->showWeatherHome())); page.addView(row1,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout row2=homeRow(); row2.addView(homeCard(R.drawable.home_trips,"Ημερολόγιο Εξορμήσεων",v->showTrips())); row2.addView(homeCard(R.drawable.home_favorites,"Αγαπημένα",v->showFavorites())); page.addView(row2,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout row3=homeRow(); row3.addView(homeCard(R.drawable.home_fish_guide,"Οδηγός Ψαριών",v->showFishGuide())); row3.addView(homeCard(R.drawable.home_techniques,"Τεχνικές και Δολώματα",v->showInfoPage("Τεχνικές & Δολώματα","Η ενότητα θα περιλαμβάνει τεχνικές ψαρέματος, εξοπλισμό και προτεινόμενα δολώματα ανά είδος ψαριού και περιοχή."))); page.addView(row3,new LinearLayout.LayoutParams(-1,0,1));
    }
    private LinearLayout homeRow(){ LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setPadding(0,3,0,3); return row; }
    private ImageView homeCard(int image,String description,View.OnClickListener click){ ImageView v=homeImage(image,description); v.setOnClickListener(click); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1); p.setMargins(4,0,4,0); v.setLayoutParams(p); return v; }
    private ImageView homeImage(int image,String description){ ImageView v=new ImageView(this); v.setImageResource(image); v.setScaleType(ImageView.ScaleType.CENTER_CROP); v.setAdjustViewBounds(true); v.setContentDescription(description); return v; }
    private void showWeatherHome(){
        clear(); body.addView(title("Καιρός & Θάλασσα")); TextView live=card("Τρέχουσες συνθήκες","Λήψη πρόγνωσης για την Αττική και τον Σαρωνικό…"); body.addView(live); WeatherService.fetch(37.95,23.60,r->runOnUiThread(()->live.setText("Τρέχουσες συνθήκες\n\n"+r)));
    }
    private void showFishGuide(){
        clear(); LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(12,8,12,8); body.addView(page,new LinearLayout.LayoutParams(-1,-1)); page.addView(title("Οδηγός Ψαριών & Κεφαλόποδων"));
        int cephalopods=0; for(FishGuideEntry f:fishGuide)if(f.category().equals("Κεφαλόποδα"))cephalopods++; int fishCount=fishGuide.size()-cephalopods;
        TextView fishes=card("Ψάρια • "+fishCount+" είδη","Ελληνικά παράκτια και πελαγικά ψάρια με αναγνώριση, βιότοπο, εποχή, δολώματα και τεχνικές."); fishes.setOnClickListener(v->showFishGuideList("Ψάρια")); page.addView(fishes);
        TextView ceph=card("Κεφαλόποδα • "+cephalopods+" είδη","Σουπιές, χταπόδια, καλαμάρια, θράψαλα και μοσχοχτάποδα."); ceph.setOnClickListener(v->showFishGuideList("Κεφαλόποδα")); page.addView(ceph);
    }
    private void showFishGuideList(String section){
        clear(); LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(12,8,12,8); body.addView(page,new LinearLayout.LayoutParams(-1,-1));
        page.addView(title(section)); EditText search=input(section.equals("Κεφαλόποδα")?"Αναζήτηση κεφαλόποδου":"Αναζήτηση ψαριού ή οικογένειας"); page.addView(search);
        TextView warning=text("Οι πληροφορίες αφορούν αναγνώριση και τεχνικές. Πριν από κάθε εξόρμηση έλεγχε τις ισχύουσες απαγορεύσεις, τα ελάχιστα μεγέθη και τις τοπικές αποφάσεις του Λιμεναρχείου.",12,coral); warning.setPadding(10,6,10,8); page.addView(warning);
        ScrollView sc=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); sc.addView(list); page.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        Runnable render=()->renderFishGuide(list,search.getText().toString(),section); render.run(); search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){render.run();} public void afterTextChanged(Editable e){}});
    }
    private void renderFishGuide(LinearLayout list,String query,String section){
        list.removeAllViews(); String needle=query.trim().toLowerCase(Locale.ROOT); int found=0;
        for(FishGuideEntry f:fishGuide){if(section.equals("Κεφαλόποδα")&&!f.category().equals("Κεφαλόποδα"))continue; if(section.equals("Ψάρια")&&f.category().equals("Κεφαλόποδα"))continue; String hay=(f.name()+" "+f.scientific()+" "+f.category()+" "+f.baits()+" "+f.techniques()).toLowerCase(Locale.ROOT); if(!needle.isEmpty()&&!hay.contains(needle))continue; found++; TextView v=card(f.name()+"  •  "+f.category(),f.scientific()+"\n"+f.habitat()+"\nΚαλύτερη περίοδος: "+f.season()); v.setOnClickListener(x->showFishDetail(f)); list.addView(v);}
        if(found==0)list.addView(empty("Δεν βρέθηκε είδος με αυτή την αναζήτηση."));
    }
    private void showFishDetail(FishGuideEntry f){
        clear(); ScrollView sc=new ScrollView(this); LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setPadding(16,10,16,24); sc.addView(page); body.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        page.addView(title(f.name())); page.addView(text(f.scientific()+"  •  "+f.category(),14,ocean)); page.addView(card("Αναγνώριση",f.identification())); page.addView(card("Βιότοπος",f.habitat())); page.addView(card("Βάθος",f.depth())); page.addView(card("Καλύτερη περίοδος",f.season())); page.addView(card("Δολώματα",f.baits())); page.addView(card("Τεχνικές",f.techniques())); page.addView(card("Χρήσιμη σημείωση",f.notes()));
        TextView law=card("Νομοθεσία","Τα επιτρεπόμενα μεγέθη, οι περίοδοι, οι ποσότητες και οι τοπικές απαγορεύσεις μπορεί να αλλάζουν. Επιβεβαίωσέ τα από το αρμόδιο Λιμεναρχείο πριν κρατήσεις αλίευμα."); law.setTextColor(coral); page.addView(law);
    }
    private void showInfoPage(String heading,String message){ clear(); body.addView(title(heading)); body.addView(card("Σύντομα διαθέσιμο",message)); }
    private void showMap(){
        clear(); LinearLayout searchRow=new LinearLayout(this); searchRow.setPadding(10,8,10,8); EditText q=input("Αναζήτηση περιοχής, ψαριού ή τεχνικής"); Button go=button("🔎"); searchRow.addView(q,new LinearLayout.LayoutParams(0,-2,1)); searchRow.addView(go,new LinearLayout.LayoutParams(-2,-2)); body.addView(searchRow);
        map=new MapView(this); map.setTileSource(TileSourceFactory.MAPNIK); map.setMultiTouchControls(true); map.getController().setZoom(6.4); map.getController().setCenter(new GeoPoint(38.45,23.7)); body.addView(map,new LinearLayout.LayoutParams(-1,0,1));
        Runnable render=()->renderMarkers(q.getText().toString()); render.run(); go.setOnClickListener(v->render.run());
        TextView note=text("Τα πορτοκαλί σημεία είναι η αρχική βάση δεδομένων. Τα αλιευτικά χαρακτηριστικά τους επιβεβαιώνονται πριν χαρακτηριστούν επαγγελματικά δεδομένα.",12,navy); note.setPadding(12,6,12,6); body.addView(note);
    }
    private void renderMarkers(String query){
        if(map==null)return; map.getOverlays().clear(); String needle=query.trim().toLowerCase(Locale.ROOT);
        for(FishingSpot s:spots){ String hay=(s.name()+s.region()+s.fish()+s.techniques()+s.seabed()).toLowerCase(Locale.ROOT); if(!needle.isEmpty()&&!hay.contains(needle))continue;
            Marker m=new Marker(map); m.setPosition(new GeoPoint(s.lat(),s.lon())); m.setAnchor(.5f,1f); m.setTitle(s.name()); Drawable d=ContextCompat.getDrawable(this,com.fishingingreece.app.R.drawable.marker_pin); m.setIcon(d); m.setOnMarkerClickListener((marker,mv)->{showSpot(s);return true;}); map.getOverlays().add(m);
        } map.invalidate();
    }
    private void showSpot(FishingSpot s){
        clear(); ScrollView sc=new ScrollView(this); LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(20,18,20,28); sc.addView(box); body.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        box.addView(title(s.name())); box.addView(text(s.region()+"  •  "+(s.verified()?"✓ Επιβεβαιωμένο":"Υπό διασταύρωση"),14,s.verified()?ocean:coral));
        box.addView(card("Μορφολογία βυθού",s.seabed())); box.addView(card("Ενδεικτικό βάθος",s.depth())); box.addView(card("Πιθανά ψάρια",s.fish())); box.addView(card("Τεχνικές",s.techniques())); box.addView(card("Πρόσβαση",s.access())); box.addView(card("Ασφάλεια / περιορισμοί",s.warning()));
        weatherView=card("Καιρός και θάλασσα","Λήψη ζωντανής πρόγνωσης…"); box.addView(weatherView); WeatherService.fetch(s.lat(),s.lon(),r->runOnUiThread(()->weatherView.setText("Καιρός και θάλασσα\n\n"+r)));
        LinearLayout actions=new LinearLayout(this); Button fav=button(db.isFavorite(s.id())?"★ Αφαίρεση":"☆ Αγαπημένο"); Button trip=button("＋ Εξόρμηση"); actions.addView(fav,new LinearLayout.LayoutParams(0,-2,1)); actions.addView(trip,new LinearLayout.LayoutParams(0,-2,1)); box.addView(actions);
        Button navigate=button("Πλοήγηση στο σημείο"); box.addView(navigate); fav.setOnClickListener(v->{db.toggleFavorite(s.id());showSpot(s);}); trip.setOnClickListener(v->showTripForm(s)); navigate.setOnClickListener(v->{ Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("geo:"+s.lat()+","+s.lon()+"?q="+s.lat()+","+s.lon()+"("+Uri.encode(s.name())+")")); startActivity(i); });
    }
    private void showFavorites(){
        clear(); Set<Integer> ids=db.favorites(); body.addView(title("Αγαπημένοι ψαρότοποι")); if(ids.isEmpty()){body.addView(empty("Δεν έχεις αποθηκεύσει ακόμη κάποιο σημείο."));return;} for(FishingSpot s:spots)if(ids.contains(s.id()))body.addView(spotButton(s));
    }
    private void showTrips(){
        clear(); body.addView(title("Ημερολόγιο εξορμήσεων")); Button add=button("＋ Νέα εξόρμηση"); add.setOnClickListener(v->chooseSpotForTrip()); body.addView(add); ScrollView sc=new ScrollView(this); LinearLayout list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); sc.addView(list); body.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        List<String[]> trips=db.trips(); if(trips.isEmpty())list.addView(empty("Δεν έχεις καταγράψει ακόμη κάποια εξόρμηση."));
        for(String[] r:trips){ TextView c=card(r[1]+" • "+r[2],"Ώρα: "+r[3]+"–"+r[4]+"\nΨάρια/αποτέλεσμα: "+r[5]+"\nΣημειώσεις: "+r[6]+(r[8].isBlank()?"":"\n\nΣυνθήκες: "+r[8])); c.setOnLongClickListener(v->{new AlertDialog.Builder(this).setMessage("Διαγραφή αυτής της εξόρμησης;").setPositiveButton("Διαγραφή",(d,w)->{db.deleteTrip(Long.parseLong(r[0]));showTrips();}).setNegativeButton("Άκυρο",null).show();return true;}); list.addView(c); }
    }
    private void chooseSpotForTrip(){ String[] names=spots.stream().map(FishingSpot::name).toArray(String[]::new); new AlertDialog.Builder(this).setTitle("Επίλεξε ψαρότοπο").setItems(names,(d,w)->showTripForm(spots.get(w))).show(); }
    private void showTripForm(FishingSpot s){
        clear(); ScrollView sc=new ScrollView(this); LinearLayout f=new LinearLayout(this); f.setOrientation(LinearLayout.VERTICAL); f.setPadding(20,15,20,30); sc.addView(f); body.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); f.addView(title("Νέα εξόρμηση\n"+s.name()));
        EditText date=input("Ημερομηνία (π.χ. 26/08/2026)"); date.setText(new SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(new Date())); EditText start=input("Ώρα έναρξης"); EditText end=input("Ώρα λήξης"); EditText catches=input("Τι έβγαλες; είδος, τεμάχια, βάρος"); EditText notes=input("Σημειώσεις, δόλωμα, τεχνική, παρατηρήσεις"); notes.setMinLines(4); f.addView(date);f.addView(start);f.addView(end);f.addView(catches);f.addView(notes);
        TextView live=card("Συνθήκες","Λήψη τωρινών συνθηκών…");f.addView(live);WeatherService.fetch(s.lat(),s.lon(),r->runOnUiThread(()->live.setText("Συνθήκες\n\n"+r)));
        Button photo=button("📷 Προσθήκη φωτογραφίας"); photo.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,404);});f.addView(photo); Button save=button("Αποθήκευση εξόρμησης"); f.addView(save); save.setOnClickListener(v->{db.addTrip(s.id(),s.name(),date.getText().toString(),start.getText().toString(),end.getText().toString(),catches.getText().toString(),notes.getText().toString(),selectedPhoto,live.getText().toString());selectedPhoto="";Toast.makeText(this,"Η εξόρμηση αποθηκεύτηκε",Toast.LENGTH_SHORT).show();showTrips();});
    }
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==404&&res==RESULT_OK&&data!=null&&data.getData()!=null){selectedPhoto=data.getData().toString();try{getContentResolver().takePersistableUriPermission(data.getData(),Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}Toast.makeText(this,"Η φωτογραφία προστέθηκε",Toast.LENGTH_SHORT).show();}}
    private TextView spotButton(FishingSpot s){ TextView v=card(s.name(),s.region()+"\n"+s.seabed()+" • "+s.depth()+"\n"+s.fish());v.setOnClickListener(x->showSpot(s));return v; }
    private TextView title(String s){TextView v=text(s,23,navy);v.setTypeface(null,1);v.setPadding(18,18,18,12);return v;}
    private TextView empty(String s){TextView v=text(s,16,navy);v.setGravity(Gravity.CENTER);v.setPadding(30,80,30,30);return v;}
    private TextView card(String h,String value){TextView v=text(h+"\n\n"+value,16,navy);v.setBackgroundColor(Color.WHITE);v.setPadding(18,16,18,16);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,8,0,8);v.setLayoutParams(p);return v;}
    private TextView text(String s,int sp,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);return v;}
    private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(navy);e.setHintTextColor(Color.GRAY);e.setBackgroundColor(Color.WHITE);e.setPadding(14,14,14,14);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,6,0,6);e.setLayoutParams(p);return e;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(ocean));b.setAllCaps(false);return b;}
    @Override public void onBackPressed(){ showHome(); }
    @Override protected void onResume(){super.onResume();if(map!=null)map.onResume();}
    @Override protected void onPause(){if(map!=null)map.onPause();super.onPause();}
}
