package com.fishingingreece.app;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

public final class WeatherService {
    public interface Callback { void done(String result); }
    private static final ExecutorService POOL=Executors.newFixedThreadPool(2);
    private WeatherService(){}
    public static void fetch(double lat,double lon,Callback cb){
        POOL.execute(()->{
            String answer;
            try {
                String weather=get("https://api.open-meteo.com/v1/forecast?latitude="+lat+"&longitude="+lon+"&current=temperature_2m,apparent_temperature,precipitation,wind_speed_10m,wind_direction_10m,weather_code&hourly=surface_pressure&timezone=auto&forecast_days=3");
                String marine=get("https://marine-api.open-meteo.com/v1/marine?latitude="+lat+"&longitude="+lon+"&current=wave_height,wave_direction,wave_period&timezone=auto&forecast_days=3");
                JSONObject c=new JSONObject(weather).getJSONObject("current");
                JSONObject m=new JSONObject(marine).optJSONObject("current");
                answer="🌡 "+c.optDouble("temperature_2m")+" °C  •  Αίσθηση "+c.optDouble("apparent_temperature")+" °C\n"+
                       "💨 "+c.optDouble("wind_speed_10m")+" km/h από "+direction(c.optDouble("wind_direction_10m"))+"\n"+
                       "🌧 Βροχή "+c.optDouble("precipitation")+" mm";
                if(m!=null) answer += "\n🌊 Κύμα "+m.optDouble("wave_height")+" μ. • "+m.optDouble("wave_period")+" δευτ. από "+direction(m.optDouble("wave_direction"));
                answer += "\nΕνημέρωση: "+c.optString("time").replace('T',' ');
            } catch(Exception e){ answer="Δεν ήταν δυνατή η λήψη πρόγνωσης. Έλεγξε τη σύνδεση και δοκίμασε ξανά."; }
            cb.done(answer);
        });
    }
    private static String get(String value)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(value).openConnection(); c.setConnectTimeout(12000); c.setReadTimeout(12000); c.setRequestProperty("User-Agent","FishingInGreece/0.1");
        try(InputStream in=c.getInputStream()){ return new String(in.readAllBytes(), StandardCharsets.UTF_8); } finally { c.disconnect(); }
    }
    private static String direction(double d){ String[] a={"Β","ΒΑ","Α","ΝΑ","Ν","ΝΔ","Δ","ΒΔ"}; return a[(int)Math.round(d/45)%8]; }
}
