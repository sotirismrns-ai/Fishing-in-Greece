package com.fishingingreece.app;

import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

public final class WeatherService {
    public interface Callback { void done(String result); }
    private static final ExecutorService POOL=Executors.newFixedThreadPool(2);
    private WeatherService(){}
    public static void fetch(double lat,double lon,Callback cb){
        POOL.execute(()->{
            String answer;
            try {
                String weather=get("https://api.open-meteo.com/v1/forecast?latitude="+lat+"&longitude="+lon+"&current=temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,cloud_cover,surface_pressure,visibility,wind_speed_10m,wind_direction_10m,wind_gusts_10m,weather_code&timezone=auto&forecast_days=3");
                String marine=get("https://marine-api.open-meteo.com/v1/marine?latitude="+lat+"&longitude="+lon+"&current=wave_height,wave_direction,wave_period,wind_wave_height,swell_wave_height,swell_wave_direction,swell_wave_period,sea_surface_temperature,ocean_current_velocity,ocean_current_direction,sea_level_height_msl&hourly=sea_level_height_msl&forecast_hours=24&timezone=auto");
                JSONObject c=new JSONObject(weather).getJSONObject("current");
                JSONObject marineJson=new JSONObject(marine),m=marineJson.optJSONObject("current");
                answer="";
                if(m!=null){answer += "🌡 Θερμοκρασία νερού: "+number(m,"sea_surface_temperature")+" °C";
                    answer += "\n🌊 Κύμα: "+number(m,"wave_height")+" μ. • "+number(m,"wave_period")+" δευτ. από "+direction(m.optDouble("wave_direction"));
                    answer += "\n〰 Swell: "+number(m,"swell_wave_height")+" μ. • "+number(m,"swell_wave_period")+" δευτ. από "+direction(m.optDouble("swell_wave_direction"));
                    answer += "\n➡ Θαλάσσιο ρεύμα: "+number(m,"ocean_current_velocity")+" km/h προς "+direction(m.optDouble("ocean_current_direction"));
                    answer += "\n↕ Στάθμη θάλασσας/παλίρροια: "+number(m,"sea_level_height_msl")+" μ. από μέση παγκόσμια στάθμη";}
                answer += tideRange(marineJson)+"\n🌙 Σελήνη: "+moonPhase()+"\n\n🌡 Αέρας: "+number(c,"temperature_2m")+" °C  •  Αίσθηση "+number(c,"apparent_temperature")+" °C\n"+
                       "💧 Υγρασία: "+number(c,"relative_humidity_2m")+"%  •  Νέφωση "+number(c,"cloud_cover")+"%\n"+
                       "💨 Άνεμος: "+number(c,"wind_speed_10m")+" km/h από "+direction(c.optDouble("wind_direction_10m"))+" •  Ριπές "+number(c,"wind_gusts_10m")+" km/h\n"+
                       "🌧 Βροχή: "+number(c,"precipitation")+" mm  •  Πίεση "+number(c,"surface_pressure")+" hPa\n"+
                       "👁 Ορατότητα: "+String.format(java.util.Locale.getDefault(),"%.1f",c.optDouble("visibility")/1000d)+" km\n\nΕνημέρωση: "+c.optString("time").replace('T',' ')+"\nΔεδομένα καιρού/θάλασσας: Open-Meteo (CC BY 4.0).\nΠρόγνωση μοντέλου — όχι για ναυσιπλοΐα.";
            } catch(Exception e){ answer="Δεν ήταν δυνατή η λήψη πρόγνωσης. Έλεγξε τη σύνδεση και δοκίμασε ξανά."; }
            cb.done(answer);
        });
    }
    private static String get(String value)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(value).openConnection(); c.setConnectTimeout(12000); c.setReadTimeout(12000); c.setRequestProperty("User-Agent","FishingInGreece/0.1");
        try(InputStream in=c.getInputStream()){ return new String(in.readAllBytes(), StandardCharsets.UTF_8); } finally { c.disconnect(); }
    }
    private static String direction(double d){ String[] a={"Β","ΒΑ","Α","ΝΑ","Ν","ΝΔ","Δ","ΒΔ"}; return a[(int)Math.round(d/45)%8]; }
    private static String number(JSONObject o,String key){return o.isNull(key)||!o.has(key)?"—":String.format(java.util.Locale.getDefault(),"%.1f",o.optDouble(key));}
    private static String tideRange(JSONObject root){try{JSONObject h=root.getJSONObject("hourly");JSONArray times=h.getJSONArray("time"),values=h.getJSONArray("sea_level_height_msl");double low=Double.MAX_VALUE,high=-Double.MAX_VALUE;String lowTime="",highTime="";for(int i=0;i<values.length();i++){if(values.isNull(i))continue;double v=values.getDouble(i);if(v<low){low=v;lowTime=times.getString(i);}if(v>high){high=v;highTime=times.getString(i);}}if(low==Double.MAX_VALUE)return "";return "\n📉 Ελάχιστη επόμενου 24ώρου: "+String.format(java.util.Locale.getDefault(),"%.2f",low)+" μ. στις "+clock(lowTime)+"\n📈 Μέγιστη επόμενου 24ώρου: "+String.format(java.util.Locale.getDefault(),"%.2f",high)+" μ. στις "+clock(highTime);}catch(Exception e){return "";}}
    private static String clock(String iso){int t=iso.indexOf('T');return t>=0?iso.substring(t+1):iso;}
    private static String moonPhase(){double days=(System.currentTimeMillis()/86400000d)-10957.5;double age=((days%29.53058867)+29.53058867)%29.53058867;if(age<1.85)return "Νέα Σελήνη";if(age<5.54)return "Αύξων μηνίσκος";if(age<9.23)return "Πρώτο τέταρτο";if(age<12.92)return "Αύξων αμφίκυρτος";if(age<16.61)return "Πανσέληνος";if(age<20.30)return "Φθίνων αμφίκυρτος";if(age<23.99)return "Τελευταίο τέταρτο";if(age<27.68)return "Φθίνων μηνίσκος";return "Νέα Σελήνη";}
}
