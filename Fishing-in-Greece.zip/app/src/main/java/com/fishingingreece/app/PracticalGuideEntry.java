package com.fishingingreece.app;

public record PracticalGuideEntry(
        String category,
        String name,
        String english,
        String summary,
        String suitableFor,
        String setup,
        String tips) {}
