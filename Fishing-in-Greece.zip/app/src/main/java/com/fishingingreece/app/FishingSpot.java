package com.fishingingreece.app;

public final class FishingSpot {
    private final int id;
    private final String name, region, seabed, depth, fish, techniques, access, warning;
    private final double lat, lon;
    private final boolean verified;

    public FishingSpot(int id, String name, String region, double lat, double lon,
                       String seabed, String depth, String fish, String techniques,
                       String access, String warning, boolean verified) {
        this.id=id; this.name=name; this.region=region; this.lat=lat; this.lon=lon;
        this.seabed=seabed; this.depth=depth; this.fish=fish; this.techniques=techniques;
        this.access=access; this.warning=warning; this.verified=verified;
    }
    public int id(){return id;} public String name(){return name;} public String region(){return region;}
    public double lat(){return lat;} public double lon(){return lon;} public String seabed(){return seabed;}
    public String depth(){return depth;} public String fish(){return fish;} public String techniques(){return techniques;}
    public String access(){return access;} public String warning(){return warning;} public boolean verified(){return verified;}
}
