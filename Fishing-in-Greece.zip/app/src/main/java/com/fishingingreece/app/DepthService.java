package com.fishingingreece.app;

import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.*;

public final class DepthService {
    public interface Callback { void done(String result); }
    private static final ExecutorService POOL=Executors.newFixedThreadPool(2);
    private DepthService(){}
    public static void fetch(double lat,double lon,Callback cb){POOL.execute(()->{
        try{double[] samples={sample(lat,lon),sample(lat+0.002,lon),sample(lat-0.002,lon),sample(lat,lon+0.0025),sample(lat,lon-0.0025)};double center=samples[0],min=Double.MAX_VALUE,max=-Double.MAX_VALUE,total=0;int count=0;for(double value:samples)if(!Double.isNaN(value)){value=Math.abs(value);min=Math.min(min,value);max=Math.max(max,value);total+=value;count++;}if(count==0||Double.isNaN(center)){cb.done("Δεν βρέθηκε θαλάσσιο βαθυμετρικό κελί σε αυτές τις συντεταγμένες. Το σημείο πιθανόν βρίσκεται στη στεριά ή εκτός κάλυψης.");return;}double range=max-min;String shape=range<2?"Σχετικά ομαλός βυθός":range<8?"Ήπια μεταβολή / κλίση":range<25?"Έντονη κλίση ή κοντινή αποχή":"Πολύ απότομη μεταβολή / βαθιά αποχή";cb.done(String.format(Locale.getDefault(),"Βάθος στο σημείο: %.1f μ.\nΜέσο βάθος γύρω από το σημείο: %.1f μ.\nΕύρος γειτονικών δειγμάτων: %.1f–%.1f μ.\nΜορφολογία βάθους: %s\nΠηγή: EMODnet DTM — ανάλυση πλέγματος, όχι βυθόμετρο.",Math.abs(center),total/count,min,max,shape));}catch(Exception e){cb.done("Δεν ήταν δυνατή η λήψη βαθυμετρίας για αυτό το σημείο.");}
    });}
    private static double sample(double lat,double lon)throws Exception{String point=String.format(Locale.US,"POINT(%f %f)",lon,lat);String url="https://rest.emodnet-bathymetry.eu/depth_sample?geom="+URLEncoder.encode(point,StandardCharsets.UTF_8);HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(10000);c.setReadTimeout(12000);c.setRequestProperty("User-Agent","FishingInGreece/0.2.3");String raw;try(InputStream in=c.getInputStream()){raw=new String(in.readAllBytes(),StandardCharsets.UTF_8);}finally{c.disconnect();}return new JSONObject(raw).optDouble("avg",Double.NaN);}
}
