package com.fishingingreece.app;

import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.concurrent.*;

public final class DepthService {
    public interface Callback { void done(String result); }
    private static final ExecutorService POOL=Executors.newFixedThreadPool(2);
    private DepthService(){}
    public static void fetch(double lat,double lon,Callback cb){POOL.execute(()->{
        try{String point=String.format(Locale.US,"POINT(%f %f)",lon,lat);String url="https://rest.emodnet-bathymetry.eu/depth_sample?geom="+URLEncoder.encode(point,StandardCharsets.UTF_8);HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(15000);c.setRequestProperty("User-Agent","FishingInGreece/0.2.3");String raw;try(InputStream in=c.getInputStream()){raw=new String(in.readAllBytes(),StandardCharsets.UTF_8);}finally{c.disconnect();}JSONObject j=new JSONObject(raw);double avg=j.optDouble("avg",Double.NaN);cb.done(Double.isNaN(avg)?"Δεν υπάρχει διαθέσιμο δείγμα βάθους.":String.format(Locale.getDefault(),"Εκτιμώμενο βάθος πλέγματος: %.1f μ.\nΠηγή: EMODnet DTM — δεν είναι ναυτικός χάρτης.",Math.abs(avg)));}catch(Exception e){cb.done("Δεν ήταν δυνατή η λήψη βαθυμετρίας για αυτό το σημείο.");}
    });}
}
