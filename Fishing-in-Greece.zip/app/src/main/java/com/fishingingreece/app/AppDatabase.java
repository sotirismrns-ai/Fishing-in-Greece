package com.fishingingreece.app;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class AppDatabase extends SQLiteOpenHelper {
    public AppDatabase(Context c) { super(c, "fishing_in_greece.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE favorites(spot_id INTEGER PRIMARY KEY)");
        db.execSQL("CREATE TABLE trips(id INTEGER PRIMARY KEY AUTOINCREMENT, spot_id INTEGER, spot_name TEXT, trip_date TEXT, start_time TEXT, end_time TEXT, catch_text TEXT, notes TEXT, photo_uri TEXT, weather_snapshot TEXT, created_at INTEGER)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) { }
    public boolean isFavorite(int id) {
        try (Cursor c=getReadableDatabase().rawQuery("SELECT 1 FROM favorites WHERE spot_id=?",new String[]{String.valueOf(id)})) { return c.moveToFirst(); }
    }
    public void toggleFavorite(int id) {
        if (isFavorite(id)) getWritableDatabase().delete("favorites","spot_id=?",new String[]{String.valueOf(id)});
        else { ContentValues v=new ContentValues(); v.put("spot_id",id); getWritableDatabase().insert("favorites",null,v); }
    }
    public Set<Integer> favorites() {
        Set<Integer> out=new HashSet<>();
        try (Cursor c=getReadableDatabase().rawQuery("SELECT spot_id FROM favorites",null)) { while(c.moveToNext()) out.add(c.getInt(0)); }
        return out;
    }
    public long addTrip(int spotId,String spotName,String date,String start,String end,String catches,String notes,String photo,String weather) {
        ContentValues v=new ContentValues(); v.put("spot_id",spotId); v.put("spot_name",spotName); v.put("trip_date",date); v.put("start_time",start); v.put("end_time",end); v.put("catch_text",catches); v.put("notes",notes); v.put("photo_uri",photo); v.put("weather_snapshot",weather); v.put("created_at",System.currentTimeMillis());
        return getWritableDatabase().insert("trips",null,v);
    }
    public List<String[]> trips() {
        List<String[]> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,spot_name,trip_date,start_time,end_time,catch_text,notes,photo_uri,weather_snapshot FROM trips ORDER BY trip_date DESC,created_at DESC",null)) {
            while(c.moveToNext()){ String[] r=new String[9]; for(int i=0;i<9;i++) r[i]=c.isNull(i)?"":c.getString(i); out.add(r); }
        } return out;
    }
    public void deleteTrip(long id){ getWritableDatabase().delete("trips","id=?",new String[]{String.valueOf(id)}); }
}
