package com.fishingingreece.app;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class AppDatabase extends SQLiteOpenHelper {
    public AppDatabase(Context c) { super(c, "fishing_in_greece.db", null, 2); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE favorites(spot_id INTEGER PRIMARY KEY)");
        db.execSQL("CREATE TABLE trips(id INTEGER PRIMARY KEY AUTOINCREMENT, spot_id INTEGER, spot_name TEXT, trip_date TEXT, start_time TEXT, end_time TEXT, catch_text TEXT, notes TEXT, photo_uri TEXT, weather_snapshot TEXT, created_at INTEGER)");
        db.execSQL("CREATE TABLE user_spots(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, region TEXT, lat REAL NOT NULL, lon REAL NOT NULL, seabed TEXT, depth TEXT, fish TEXT, techniques TEXT, notes TEXT, photo_uri TEXT, created_at INTEGER)");
    }
    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) { if(oldV<2) db.execSQL("CREATE TABLE IF NOT EXISTS user_spots(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, region TEXT, lat REAL NOT NULL, lon REAL NOT NULL, seabed TEXT, depth TEXT, fish TEXT, techniques TEXT, notes TEXT, photo_uri TEXT, created_at INTEGER)"); }
    public boolean isFavorite(int id) {
        try (Cursor c=getReadableDatabase().rawQuery("SELECT 1 FROM favorites WHERE spot_id=?",new String[]{String.valueOf(id)})) { return c.moveToFirst(); }
    }
    public void toggleFavorite(int id) {
        if (isFavorite(id)) getWritableDatabase().delete("favorites","spot_id=?",new String[]{String.valueOf(id)});
        else { ContentValues v=new ContentValues(); v.put("spot_id",id); getWritableDatabase().insert("favorites",null,v); }
    }
    public Set<Integer> favorites() {
        Set<Integer> out=new HashSet<>();
        try (Cursor c=getReadableDatabase().rawQuery("SELECT spot_id FROM favorites",null)) { while(c.moveToNext()) out.add(c.getInt(0)); }
        return out;
    }
    public long addTrip(int spotId,String spotName,String date,String start,String end,String catches,String notes,String photo,String weather) {
        ContentValues v=new ContentValues(); v.put("spot_id",spotId); v.put("spot_name",spotName); v.put("trip_date",date); v.put("start_time",start); v.put("end_time",end); v.put("catch_text",catches); v.put("notes",notes); v.put("photo_uri",photo); v.put("weather_snapshot",weather); v.put("created_at",System.currentTimeMillis());
        return getWritableDatabase().insert("trips",null,v);
    }
    public List<String[]> trips() {
        List<String[]> out=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,spot_name,trip_date,start_time,end_time,catch_text,notes,photo_uri,weather_snapshot FROM trips ORDER BY trip_date DESC,created_at DESC",null)) {
            while(c.moveToNext()){ String[] r=new String[9]; for(int i=0;i<9;i++) r[i]=c.isNull(i)?"":c.getString(i); out.add(r); }
        } return out;
    }
    public void deleteTrip(long id){ getWritableDatabase().delete("trips","id=?",new String[]{String.valueOf(id)}); }
    public long addUserSpot(String name,String region,double lat,double lon,String seabed,String depth,String fish,String techniques,String notes,String photoUri){
        ContentValues v=new ContentValues();v.put("name",name);v.put("region",region);v.put("lat",lat);v.put("lon",lon);v.put("seabed",seabed);v.put("depth",depth);v.put("fish",fish);v.put("techniques",techniques);v.put("notes",notes);v.put("photo_uri",photoUri);v.put("created_at",System.currentTimeMillis());return getWritableDatabase().insert("user_spots",null,v);
    }
    public List<FishingSpot> userSpots(){List<FishingSpot> out=new ArrayList<>();try(Cursor c=getReadableDatabase().rawQuery("SELECT id,name,region,lat,lon,seabed,depth,fish,techniques,notes,photo_uri FROM user_spots ORDER BY created_at DESC",null)){while(c.moveToNext())out.add(new FishingSpot(-c.getInt(0),c.getString(1),value(c,2),c.getDouble(3),c.getDouble(4),value(c,5),value(c,6),value(c,7),value(c,8),"Δική σου πινέζα","Έλεγξε τις τοπικές απαγορεύσεις και την ασφαλή πρόσβαση.",true,value(c,9),value(c,10)));}return out;}
    public void deleteUserSpot(int negativeId){getWritableDatabase().delete("user_spots","id=?",new String[]{String.valueOf(Math.abs(negativeId))});}
    private String value(Cursor c,int column){return c.isNull(column)?"":c.getString(column);}
}
