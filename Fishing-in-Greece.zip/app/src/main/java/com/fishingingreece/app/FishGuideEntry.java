package com.fishingingreece.app;

public record FishGuideEntry(
        String name,
        String scientific,
        String category,
        String identification,
        String habitat,
        String depth,
        String season,
        String baits,
        String techniques,
        String notes) {}
